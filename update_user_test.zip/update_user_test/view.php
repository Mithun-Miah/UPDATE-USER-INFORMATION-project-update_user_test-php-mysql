<?php
session_start();

// database connection
$connect = mysqli_connect('localhost','root','','lbms');

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

$sql = "SELECT * FROM register_users";
$query = mysqli_query($connect,$sql);

while ($data = mysqli_fetch_array($query)){
	$user_id = $data['id'];
	$user_name = $data['full_name'];
	$dept_name = $data['dept_name'];
	$email = $data['email'];

	echo $user_name.' | '.$dept_name.' | '.$email.' <a href="edit.php?id='.$user_id.'">Edit</a><br>';
}

/*$data = mysqli_fetch_array($query);
$uder_id = $data['id'];
$user_name = $data['full_name'];
$dept_name = $data['dept_name'];
$email = $data['email'];

echo $user_name.' | '.$dept_name.' | '.$email.' <a href="edit.php?id='.$uder_id.'">Edit</a>';*/

?>