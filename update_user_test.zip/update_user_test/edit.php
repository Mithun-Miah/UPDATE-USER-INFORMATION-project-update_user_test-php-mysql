<?php
session_start();

// database connection
$connect = mysqli_connect('localhost','root','','lbms');

if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

$getid = $_GET['id'];

$sql = "SELECT * FROM register_users WHERE id = $getid";

$query = mysqli_query($connect,$sql);
$data = mysqli_fetch_array($query);

$user_id = $data['id'];
$user_name = $data['full_name'];
$dept_name = $data['dept_name'];
$email = $data['email'];

if(isset($_POST['name']) && isset($_POST['email']) && isset($_POST['dept']) && isset($_POST['id'])){
    $id = $_POST['id'];
	$name = $_POST['name'];
    $email = $_POST['email'];
    $dept = $_POST['dept'];
	
	$sql = "UPDATE register_users SET full_name='$name', dept_name='$dept', email='$email' WHERE id=$id";

    if(mysqli_query($connect, $sql)){
		
		echo 'Data Updated';
		header('Location: view.php');
	}else{
		echo 'Data Updated Failed';
	}
    
} 


?>

<form action="edit.php" method="post" style="width:500px;margin:auto;">
                <h3 style="text-align:center; color:blue; font-weight:700;">UPDATE USER INFORMATION</h3>
                <input type="text" value="<?php echo $user_id; ?>" name="id" hidden> <br><br>
                <input type="text" value="<?php echo $user_name; ?>" name="name" require> <br><br>
                <input type="email" value="<?php echo $email; ?>" name="email" require>
                <br><br>
                <input type="text" value="<?php echo $dept_name; ?>" name="dept" require>
                <br><br>
                <!-- <input type="submit" value="Submit"> -->
                <button name="edit">Update Data</button>

                <a href="view.php" style="text-decoration:none;">Back Dashboard</a>
            </form>